package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpa11Application {

	public static void main(String[] args) {
		SpringApplication.run(Jpa11Application.class, args);
	}

}
